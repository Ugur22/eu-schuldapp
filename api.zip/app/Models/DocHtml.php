<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DocHtml extends Model
{
   protected $table = 'doc_htmls';
}
