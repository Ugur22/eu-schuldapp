<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<table style="font-size: 9px; text-align: justify; " cellspacing="2" >

  <tr>
    <td colspan="11" style="text-align: center; "><img src="http://api.arsus.nl/images/logo.jpg" width="150"><br/>
      Dorpsstraat vo Steenstraat 12, 3732 HJ De Bilt<br/>
      Bemiddeling & Inkomensbeheer
    </td>
  </tr>
  
  <tr><td colspan="11"></td></tr>

  <tr>
    <td colspan="6"></td>
    <td colspan="5"><b>Akte van Cessie / Pandakte</b></td>
  </tr>

  <tr><td colspan="11"></td></tr>

  <tr><td colspan="11"></td></tr>

  <tr>
    <td colspan="5"><b>Ondergetekende(n):</b></td>
    <td colspan="6"></td>
  </tr>

  <tr><td colspan="11"></td></tr>

  <tr>
    <td colspan="3">Naam:</td>
    <td colspan="2"><!--firstname--> <!--lastname--></td>
    <td colspan="6"></td>
  </tr>

  <tr>
    <td colspan="3">Adres:</td>
    <td colspan="2"><!--address--></td>
    <td colspan="6"></td>
  </tr>

  <tr>
    <td colspan="3">Postcode:</td>
    <td colspan="2"><!--postal_code--></td>
    <td colspan="6"></td>
  </tr>

  <tr>
    <td colspan="3">Plaats:</td>
    <td colspan="2"><!--place_name--></td>
    <td colspan="6"></td>
  </tr>

  <tr>
    <td colspan="3">Geb.datum:</td>
    <td colspan="2"><!--date_format(birth_date)--></td>
    <td colspan="6"></td>
  </tr>

  <tr><td colspan="11"></td></tr>

  <tr>
    <td colspan="11">Hierna te noemen "cedent" of "pandgever":<br/>
      <br/>
      De financiële dienstverlening EU-Bewindvoering B.V. gevestigd aan de Dorpstraat vo Steenstraat 12, 3732 HJ De Bilt.<br/>
      <br/>
      <br/>
      Hierna te noemen "cessionaris"of "pandnemer".
    </td>
  </tr>

  <tr><td colspan="11"></td></tr>

  <tr><td colspan="11"></td></tr>

  <tr>
    <td colspan="6"></td>
    <td colspan="5"><b><u>In aanmerking nemende</u></b></td>
  </tr>

  <tr><td colspan="11"></td></tr>

  <tr>
    <td colspan="11">Dat cessionaris of pandnemer een vordering tot nakoming  heeft op cedent of pandgever uit hoofde van het tussen partijen gesloten schuldhulp contract t.b.v. de aflossing van diverse schulden (thans) €....................<br/>
      Dat cedent of pandgever een vordering heeft op de hierna te noemen derde te zake het aan hem/haar toekomende salaris of uitkering;<br/>
      Dat cedent of pandgever ter delging van zijn/haar schuld aan cessionaris of pandnemer als navolgend overdraagt.
    </td>
  </tr>

  <tr><td colspan="11"></td></tr>

  <tr><td colspan="11"></td></tr>

  <tr>
    <td colspan="6"></td>
    <td colspan="5"><b><u>Komen als volgt overeen</u></b></td>
  </tr>

  <tr><td colspan="11"></td></tr>

  <tr>
    <td colspan="11">Cedent of pandgever draagt hierbij over aan cessionaris of pandnemer, gelijk cessionaris of pandnemer aanvaard al zijn bestaande en toekomstige vorderingen uit hoofde van zijn/haar dienstverband of uitkering.
    </td>
  </tr>

  <tr><td colspan="11"></td></tr>

  <tr><td colspan="11"></td></tr>

  <tr>
    <td colspan="5"><b>b)</b></td>
    <td colspan="6"></td>
  </tr>

  <tr>
    <td colspan="3">Werkgever/Uitkeringsinstantie:</td>
    <td colspan="8"><!--employer_name--></td>
  </tr>
  
  <tr>
    <td colspan="3">Adres:</td>
    <td colspan="8"><!--employer_address--></td>
  </tr>
  
  <tr>
    <td colspan="3">Postcode en Plaats:</td>
    <td colspan="8"><!--employer_postal_code--> <!--employer_place_name--></td>
  </tr>
  
  <tr>
    <td colspan="3">Telefoon:</td>
    <td colspan="8"><!--employer_phone--></td>
  </tr>
  
  <tr><td colspan="11"></td></tr>

  <tr><td colspan="11"></td></tr>

  <tr><td colspan="11"></td></tr>

  <tr><td colspan="11"></td></tr>

  <tr><td colspan="11"></td></tr>

  <tr>
    <td colspan="8"></td>
    <td colspan="3"><img width="140" src="<!--sign_client-->"><br/>
    Paraaf....................</td>
  </tr>
</table>

<!--PAGEBREAK-->

<table style="font-size: 9px; text-align: justify; " cellspacing="2" >

  <tr>
    <td colspan="6"></td>
    <td colspan="5"><b>Vervolg Akte van Cessie / Pandakte</b></td>
  </tr>

  <tr><td colspan="11"></td></tr>

  <tr><td colspan="11"></td></tr>

  <tr>
    <td colspan="11">Gehele loon en/of uitkering a.d. €...................., vakantiegeld en/of andere soortgelijke inkomsten dient in zijn geheel te worden ingehouden per maand/per vier weken en/of per week, naar onderstaand rekeningnummer.<br/>
      <br/>
      <br/>
      Cedent of pandgever stemt ermee in dat  EU-Bewindvoering B.V. het bedrag voor cessionaris of pandnemer zal inhouden op het loon-uitkeringen/vakantiegeld en andere inkomsten en zal overboeken op onderstaand rekening.<br/>
      <br/>
      <br/>
      Bankrekeningnummer: <b>( SNS REKENING )</b>  t.n.v.  <b>EU-Bewindvoering B.V. De Bilt</b><br/>
      <b>(t.n.v. aan te geven als EU-Bewindvoering B.V.).</b><br/>
      <br/>
      <br/>
      Cedent of pandgever erkent dat cessionaris of pandnemer bevoegd zal zijn de vereiste wettelijke mededeling te doen aan EU-Bewindvoering B.V., dat in ieder geval door dit afschrift te zenden van deze Akte van  Cessie / Pandakte.<br/>
      <br/>
      <br/>
      Cedent of pandgever verklaart hierbij ook op de hoogte te zijn dat traject plus/minus 36 á 60 maanden in beslag zal nemen.<br/>
      Per maand wordt een bedrag voor budgetbeheer in rekening gebracht (volgens LOK richtlijn).<br/>
      <br/>
      <br/>
      De Akte van Cessie / Pandakte zal in elk geval overdraagbaar zijn, wanneer er van werkgever en/of uitkering instantie wordt verandert. Deze overeenkomst zal automatisch worden ontbonden zodra EU-Bewindvoering B.V. tot betaling van het gehele bedrag is overgegaan en het bedrag zal bijgeschreven zijn op de door cessionaris of pandnemer namens cedent of pandgever geopende rekening.<br/>
      <br/>
      <br/>
      Aldus overeengekomen en in drievoud ondertekend te:
    </td>
  </tr>

  <tr><td colspan="11"></td></tr>
  
  <tr><td colspan="11"></td></tr>
    
  <tr>
    <td colspan="3">Datum:</td>
    <td colspan="2"><!--date_format(doc_date_time)--></td>
    <td colspan="1"></td>
    <td colspan="3">Plaats:</td>
    <td colspan="2">De Bilt</td>
  </tr>
  
  <tr><td colspan="11"></td></tr>
    
  <tr>
    <td colspan="3">Cedent/Pandgever:</td>
    <td colspan="3"><img width="140" src="<!--sign_client-->"></td>
    <td colspan="5"></td>
  </tr>
  
  <tr><td colspan="11"></td></tr>
    
  <tr>
    <td colspan="3">Cessionaris/Pandnemer:</td>
    <td colspan="3"><img width="140" src="<!--sign_consultant-->"></td>
    <td colspan="1"></td>
    <td colspan="4">EU-Bewindvoering B.V.</td>
  </tr>
  
</table>