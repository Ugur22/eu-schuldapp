<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<table style="font-size: 9px; text-align: justify; " cellspacing="2" >

  <tr>
    <td colspan="11" style="text-align: center; "><img src="http://api.arsus.nl/images/logo.jpg" width="150"><br/>
      Dorpsstraat vo Steenstraat 12, 3732 HJ De Bilt<br/>
      Bemiddeling & Inkomensbeheer
    </td>
  </tr>
  
  <tr><td colspan="11"></td></tr>

  <tr>
    <td style="text-align: center; " colspan="11"><b>Volmacht verstrekt aan cliënt EU-Bewindvoering B.V.</b></td>
  </tr>
  
  <tr><td colspan="11"></td></tr>

  <tr>
    <td colspan="3">Name:</td>
    <td colspan="8"><!--firstname--> <!--lastname--></td>
  </tr>

  <tr><td colspan="11"></td></tr>

  <tr>
    <td colspan="3">Adres:</td>
    <td colspan="8"><!--address--> <!--postal_code--> <!--place_name--></td>
  </tr>

  <tr><td colspan="11"></td></tr>

  <tr>
    <td colspan="3">Datum:</td>
    <td colspan="8"><!--date_format(signed_date_client)--></td>
  </tr>

  <tr><td colspan="11"></td></tr>

  <tr><td colspan="11">Onderwerp: Inventarisatie,gerechtelijke procedure en anders<br/>
    <br/>
    Ons dossier<br/>
    Uw dossier<br/>
    <br/>
    Geachte heer/mevrouw,<br/>
    <br/>
    Met verwijzing naar artikel 35 van de Wet bescherming persoonsgegevens verzoeken wij u ons namens cliënt, kenbaar te maken of er op dit moment openstaande vorderingen zijn. Aangezien wij voor cliënt(en) met een schuldbemiddeling traject bezig zijn, verzoeken wij u vriendelijk eventuele openstaande schulden met ons te delen.<br/>
    <br/>
    Indien de vordering niet meer bij u in behandeling is, vernemen wij dit graag.<br/>
    <br/>
    Bijgevoegd is een kopie legitimatiebewijs van cliënt(e).
  </td></tr>
  
  <tr><td colspan="11"></td></tr>

  <tr>
    <td colspan="3">Naam:</td>
    <td colspan="3"><!--firstname--> <!--lastname--></td>
    <td colspan="5"></td>
  </tr>

  <tr>
    <td colspan="3">Geboortedatum:</td>
    <td colspan="3"><!--date_format(birth_date)--></td>
    <td colspan="5"></td>
  </tr>

  <tr>
    <td colspan="3">Adres:</td>
    <td colspan="3"><!--address--></td>
    <td colspan="5"></td>
  </tr>

  <tr>
    <td colspan="3">Postcode:</td>
    <td colspan="3"><!--postal_code--></td>
    <td colspan="5"></td>
  </tr>

  <tr>
    <td colspan="3">Plaats:</td>
    <td colspan="3"><!--place_name--></td>
    <td colspan="5"></td>
  </tr>
  
  <tr><td colspan="11"></td></tr>

  <tr><td colspan="11"><img width="140" src="<!--signed_client-->"><br/>
    Handtekening..............................<br/>
  </td></tr>
  
</table>