<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<div><span style="font-family: trebuchet ms;"><span style="font-family: trebuchet ms;">De Bilt, <!--date_format(doc_date_time)--><br /> <br /></span></span>
  <div><span style="font-family: trebuchet ms;"><span style="font-family: trebuchet ms;">Geachte <!--gender--> <!--initial--> <!--firstname--> <!--lastname-->,<br /> <br /></span></span>
  <div><span style="font-family: trebuchet ms;"><span style="font-family: trebuchet ms;">Graag uw aandacht voor bijgesloten documenten.<br /> <br /></span></span>
  <div><span style="font-family: trebuchet ms;"><span style="font-family: trebuchet ms;">Mocht u nog vragen en/of opmerkingen hebben, dan horen wij dat graag.<br /> <br /></span></span>
  <div><span style="font-family: trebuchet ms;"><span style="font-family: trebuchet ms;">Vertrouwende u voldoende te hebben ge&iuml;nformeerd.<br /> <br /></span></span>
  <div><span style="font-family: trebuchet ms;">Met vriendelijke groet,</span></div>
  <div><span style="font-family: trebuchet ms;">Team EU-Bewindvoering</span>
  <div><span style="font-family: trebuchet ms;"><a href="http://eu-bewindvoering.nl/"><img class="fr-fic fr-dii" style="border: 0px solid;" src="http://eu-bewindvoering.nl/wp-content/uploads/2017/06/SmallLogo.png" alt="" width="215" height="130" /></a></span></div>
  <div><span style="font-family: trebuchet ms;"><span style="font-size: 14px;">Dorpsstraat vo Steenstraat 12<br />3732 HJ De Bilt</span></span></div>
  <div><span style="font-family: trebuchet ms;"><span style="font-size: 14px;">Tel: 085-0514029&nbsp;</span></span></div>
  <div><span style="font-family: trebuchet ms;"><span style="font-size: 14px;">&nbsp;</span></span></div>
  <div><span style="font-family: trebuchet ms;"><span style="font-size: 14px;">Postadres:&nbsp;</span></span></div>
  <div><span style="font-family: trebuchet ms;"><span style="font-size: 14px;">Postbus 24085</span></span></div>
  <div><span style="font-family: trebuchet ms;"><span style="font-size: 14px;">3502 MB te Utrecht</span></span></div>
  <div><span style="font-family: trebuchet ms;">&nbsp;</span></div>
  <div><span style="font-size: 9px; font-family: 'trebuchet ms';">Dit bericht is vertrouwelijk, alsmede eventuele bijlagen. Mocht u het ten onrechte hebben ontvangen, dan vragen wij u de afzender hiervan zo spoedig mogelijk op de hoogte te stellen en het bericht (plus eventuele bijlage) te verwijderen uit uw systeem. Onbevoegde verspreiding en/of misbruik van de inhoud zijn niet toegestaan. Wij wijzen u erop dat e-mailberichten aan wijziging onderhevig kunnen zijn. EU-Bewindvoering is niet aansprakelijk voor onjuiste en/of onvolledige overdracht van informatie uit dit bericht. Evenmin is zij aansprakelijk voor mogelijke vertraging in de ontvangst en/of schade door dit bericht.</span></div>
  <span style="font-family: trebuchet ms;"><span style="font-family: trebuchet ms;"></span></span>
  <p>&nbsp;</p>
  </div>
  </div>
  </div>
 