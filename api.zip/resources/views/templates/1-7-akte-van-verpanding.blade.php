<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<table style="font-size: 9px; text-align: justify; " cellspacing="2" >

  <tr>
    <td colspan="11" style="text-align: center; "><img src="http://api.arsus.nl/images/logo.jpg" width="150"><br/>
      Dorpsstraat vo Steenstraat 12, 3732 HJ De Bilt<br/>
      Bemiddeling & Inkomensbeheer
    </td>
  </tr>
  
  <tr><td colspan="11"></td></tr>

  <tr>
    <td style="text-align: center; " colspan="11"><b>Akte van Verpanding</b></td>
  </tr>

  <tr><td colspan="11"><br/>
    <br/>
    <br/>
    <b>Ondergetekende(n):<br/>
    <br/>
    <!--firstname--> <!--lastname--><br/>
    wonende <!--address--><br/>
    te <!--place_name--><br/>
    Verder te noemen cliënt(en),<br/>
    <br/>
    en<br/>
    <br/>
    EU-Bewindvoering B.V., gevestigd te Dorpstraat vo Steenstraat 12, 3732 HJ De Bilt,
    verder te noemen<br/>
    EU-Bewindvoering B.V. Tezamen  ook wel partijen genoemd,<br/>
    <br/>
    <br/>
    in aanmerking nemende:<br/>
    </b>
    <br/>
    <br/>
    <br/>
    <b>A.</b> Dat EU-Bewindvoering B.V. (of aan haar gelieerde ondernemingen) een vordering tot nakoming heeft op de cliënt(en) uit hoofde van het tussen partijen gesloten schuldhulp contract t.b.v. voor deze cliënt(en) verrichte werkzaamheden.<br/>
    <br/>
    <b>B.</b> Dat het EU-Bewindvoering B.V. bekend is dat cliënt(en) ook aan andere schuldeisers betalingsverplichtingen heeft.<br/>
    <br/>
    <b>C.</b> Dat het mogelijk is dat andere schuldeiser(s) beslag willen (gaan) leggen op de inboedel om annex is ter zekerheidstelling van terugbetaling van hun vorderingen;<br/>
    <br/>
    <b>zijn overeengekomen als volgt:</b><br/>
    <br/>
    <br/>
    <b>1.</b> Cliënt(en) verpand zijn/haar inboedel en overige van waarde zijnde goederen, waarvan tussen partijen waarvan tussen partijen is overeengekomen dat geen opnamestaat zal worden opgemaakt, aan EU-Bewindvoering B.V. gedurende de looptijd van de geldleningen van EU-Bewindvoering B.V. aan cliënt(en). Na gehele betaling inclusief de betaling van de verschuldigde rente en kosten, zal de inboedel en overige van waarde zijnde goederen van rechtswege wederom ter beschikking komen aan cliënt(en).<br/>
    <br/>
    <b>2.</b> Cliënt(en) is gehouden EU-Bewindvoering B.V. terstond te informeren indien een schuldeiser(s) van cliënt(en) aan cliënt(en) mededeling doet van beslaglegging op inboedel of inkomsten.<br/>
    <br/>
    <br/>
    Aldus overeengekomen en in tweevoud ondertekend De Bilt op <!--date_format(doc_date_signed)--><br/>
    (Bewindvoering B.V.)<br/>
  </td></tr>

  <tr><td colspan="11"></td></tr>
  
  <tr><td colspan="11"></td></tr>
  
  <tr>
    <td colspan="3">Datum</td>
    <td colspan="2"><!--date_format(date_signed_client)--></td>
    <td colspan="1"></td>
    <td colspan="3">Datum</td>
    <td colspan="2"><!--date_format(date_signed_consultant)--></td>
  </tr>
  
  <tr><td colspan="11"></td></tr>
  
  <tr>
    <td colspan="3">Schuldenaar</td>
    <td colspan="2"><!--firstname--> <!--lastname--></td>
    <td colspan="1"></td>
    <td colspan="3">Schuldhulp bem.</td>
    <td colspan="2"></td>
  </tr>
  
  <tr>
    <td colspan="3"></td>
    <td colspan="2"></td>
    <td colspan="1"></td>
    <td colspan="3">EU-Bewindvoering B.V.</td>
    <td colspan="2"></td>
  </tr>
  
  <tr>
    <td colspan="5"><img width="140" src="<!--signed_client-->"><br/>
    Handtekening..............................</td>
    <td colspan="1"></td>
    <td colspan="5"><img width="140" src="<!--signed_consultant-->"><br/>
    Handtekening..............................</td>
  </tr>
    
</table>